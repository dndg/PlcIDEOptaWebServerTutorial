# 1 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
# 2 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino" 2

/* opta_1.1.0
      - ArduinoHttpClient (0.6.0)
      - Ethernet (1.0.0)
*/

struct PLCSharedVarsInput_t
{
 bool in_PinValue;
};
PLCSharedVarsInput_t& PLCIn = (PLCSharedVarsInput_t&)m_PLCSharedVarsInputBuf;

struct PLCSharedVarsOutput_t
{
};
PLCSharedVarsOutput_t& PLCOut = (PLCSharedVarsOutput_t&)m_PLCSharedVarsOutputBuf;


AlPlc AxelPLC(-1093569634);

# 23 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino" 2
# 24 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino" 2
# 25 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino" 2
# 26 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino" 2

#define LED_PATH "/led"
#define HTTP_GET "GET"
#define MAX_PATH_LEN 2048
#define MAX_METHOD_LEN 16

// Indirizzo IP e porta del server
IPAddress ip(192, 168, 10, 15);
int port = 80;
EthernetServer server(port);

// Valore iniziale dei LED
bool pinVal = true;

void setup() {
  // Assegna indirizzo IP e avvia server
  Ethernet.begin(ip);
  server.begin();

 AxelPLC.Run();
}

void loop() {
  EthernetClient client = server.available();
  if (client) {
    HttpClient http = HttpClient(client, ip, port);
    while (client.connected()) {
      char method[16], path[2048];
      getHttpMethodAndPath(&http, method, path);
      // Se il path � "/led"
      if (strncmp(path, "/led", 2048) == 0) {
        // Se il metodo � GET
        if (strncmp(method, "GET", 16) == 0) {
          toggleLEDs();
        } else {
          badRequest(&client);
        }
      } else {
        notFound(&client);
      }
      // Disconnessione del client una volta processata la richiesta
      break;
    }
    client.stop();
  }
}

void toggleLEDs() {
  PLCIn.in_PinValue = pinVal;
  pinVal = !pinVal;
}

void getHttpMethodAndPath(HttpClient *http, char *method, char *path) {
  size_t l = http->readBytesUntil(' ', method, 16 - 1);
  method[l] = '\0';
  l = http->readBytesUntil(' ', path, 2048 - 1);
  path[l] = '\0';
}

void notFound(EthernetClient *client) {
  client->println("HTTP/1.1 404 Not Found");
  client->println("Connection: close");
  client->println("Content-Length: 0");
  client->println();
}

void badRequest(EthernetClient *client) {
  client->println("HTTP/1.1 400 Bad Request");
  client->println("Connection: close");
  client->println("Content-Length: 0");
  client->println();
}
