#include <Arduino.h>
#line 1 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
#include <AlPlc_Opta.h>

/* opta_1.1.0
      - ArduinoHttpClient (0.6.0)
      - Ethernet (1.0.0)
*/

struct PLCSharedVarsInput_t
{
	bool in_PinValue;
};
PLCSharedVarsInput_t& PLCIn = (PLCSharedVarsInput_t&)m_PLCSharedVarsInputBuf;

struct PLCSharedVarsOutput_t
{
};
PLCSharedVarsOutput_t& PLCOut = (PLCSharedVarsOutput_t&)m_PLCSharedVarsOutputBuf;


AlPlc AxelPLC(-1093569634);

#include <Portenta_Ethernet.h>
#include <EthernetServer.h>
#include <EthernetClient.h>
#include <ArduinoHttpClient.h>

#define LED_PATH "/led"
#define HTTP_GET "GET"
#define MAX_PATH_LEN 2048
#define MAX_METHOD_LEN 16

// Indirizzo IP e porta del server
IPAddress ip(192, 168, 10, 15);
int port = 80;
EthernetServer server(port);

// Valore iniziale dei LED
bool pinVal = true;

#line 40 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void setup();
#line 48 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void loop();
#line 73 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void toggleLEDs();
#line 78 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void getHttpMethodAndPath(HttpClient *http, char *method, char *path);
#line 85 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void notFound(EthernetClient *client);
#line 92 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void badRequest(EthernetClient *client);
#line 40 "C:\\Users\\fabri\\Documents\\OptaWebServer\\LLSketch\\LLSketch.ino"
void setup() {
  // Assegna indirizzo IP e avvia server
  Ethernet.begin(ip);
  server.begin();

	AxelPLC.Run();
}

void loop() {
  EthernetClient client = server.available();
  if (client) {
    HttpClient http = HttpClient(client, ip, port);
    while (client.connected()) {
      char method[MAX_METHOD_LEN], path[MAX_PATH_LEN];
      getHttpMethodAndPath(&http, method, path);
      // Se il path � "/led"
      if (strncmp(path, LED_PATH, MAX_PATH_LEN) == 0) {
        // Se il metodo � GET
        if (strncmp(method, HTTP_GET, MAX_METHOD_LEN) == 0) {
          toggleLEDs();
        } else {
          badRequest(&client);
        }
      } else {
        notFound(&client);
      }
      // Disconnessione del client una volta processata la richiesta
      break;
    }
    client.stop();
  }
}

void toggleLEDs() {
  PLCIn.in_PinValue = pinVal;
  pinVal = !pinVal;
}

void getHttpMethodAndPath(HttpClient *http, char *method, char *path) {
  size_t l = http->readBytesUntil(' ', method, MAX_METHOD_LEN - 1);
  method[l] = '\0';
  l = http->readBytesUntil(' ', path, MAX_PATH_LEN - 1);
  path[l] = '\0';
}

void notFound(EthernetClient *client) {
  client->println("HTTP/1.1 404 Not Found");
  client->println("Connection: close");
  client->println("Content-Length: 0");
  client->println();
}

void badRequest(EthernetClient *client) {
  client->println("HTTP/1.1 400 Bad Request");
  client->println("Connection: close");
  client->println("Content-Length: 0");
  client->println();
}

